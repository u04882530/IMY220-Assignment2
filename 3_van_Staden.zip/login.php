<?php
	// See all errors and warnings
	error_reporting(E_ALL);
	ini_set('error_reporting', E_ALL);

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "dbUser";
	$mysqli = mysqli_connect($server, $username, $password, $database);

	$email = isset($_POST["loginEmail"]) ? $_POST["loginEmail"] : false;
	$pass = isset($_POST["loginPass"]) ? $_POST["loginPass"] : false;

	$query = "SELECT * FROM tbusers WHERE email = '$email' AND password = '$pass'";

	$res = mysqli_query($mysqli, $query);

	$row = mysqli_fetch_array($res);
	$userid = $row["user_id"];

	$folderName = "gallery/";

	
if(isset($_FILES["picToUpload"])){
		$newFileName = $_FILES["picToUpload"];
		$numFiles = count($newFileName["name"]);

		$uploadStatus = false;

		for($i = 0; $i < $numFiles; $i++)
		{
			if( $newFileName["size"][$i] < 1000000 && ($newFileName["type"][$i] == "image/jpeg" || $newFileName["type"][$i] == "image/png") )
			{
				if($newFileName["error"][$i] > 0)
				{
					echo "Error: " . $newFileName["error"][$i] . 
					"<br/>";
				}
				else
				{
					$newFileNameName = $newFileName["name"][$i];

					$sql = "INSERT INTO tbgallery (user_id, filename) VALUES ($userid, '$newFileName')";
					$mysqli->query($sql);
					
					$uploadStatus = true;
				}
			}
		}	
		if($uploadStatus)
		{
			echo 	'<div class="alert" role="alert">
  						upload succesfull
  					</div>';
		}
  		else
  		{
  			echo 	'<div class="alert" role="alert">
  						Uplaod failed
  					</div>';
  		}
	}
	
	
	// if email and/or pass POST values are set, set the variables to those values, otherwise make them false
?>

<!DOCTYPE html>
<html>
<head>
	<title>IMY 220 - Assignment 2</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css" />
	<meta charset="utf-8" />
	<meta name="author" content="Benjamin van Staden">
	<!-- Replace Name Surname with your name and surname -->
</head>
<body>
	<div class="container">
		<?php
			if($email && $pass){
				$query = "SELECT * FROM tbusers WHERE email = '$email' AND password = '$pass'";
				$res = $mysqli->query($query);
				if($row = mysqli_fetch_array($res)){
					echo 	"<table class='table table-bordered mt-3'>
								<tr>
									<td>Name</td>
									<td>" . $row['name'] . "</td>
								<tr>
								<tr>
									<td>Surname</td>
									<td>" . $row['surname'] . "</td>
								<tr>
								<tr>
									<td>Email Address</td>
									<td>" . $row['email'] . "</td>
								<tr>
								<tr>
									<td>Birthday</td>
									<td>" . $row['birthday'] . "</td>
								<tr>
							</table>";
				
					echo 	"<form>
								<div class='form-group'>
									<input type='file' class='form-control' name='picToUpload' id='picToUpload' 
									multiple='multiple'/><br/>
									<input type='hidden' class='form-control' name='email' value='" . $_POST["loginEmail"] . "' />
								<input type='hidden' class='form-control' name='pass' value='" . $_POST["loginPass"] . "' />
									<input type='submit' class='btn btn-standard' value='Upload Image' name='submit' />
								</div>
						  	</form>";

			$query = "SELECT * FROM tbgallery WHERE user_id = $userid";
				$res = $mysqli->query($query);

				if($res->num_rows != 0){
					echo "<h1>Image Gallery</h1>";

					while($row = mysqli_fetch_array($res)){
						echo "<div style='background-image: url(".$folderName.$row["filename"].")'></div>";
					}
				}			
			}
				
				else{
					echo 	'<div class="alert alert-danger mt-3" role="alert">
	  							You are not registered on this site!
	  						</div>';
				}
			} 
			else{
				echo 	'<div class="alert alert-danger mt-3" role="alert">
	  						Could not log you in
	  					</div>';
			}

		?>
	</div>
</body>
</html>